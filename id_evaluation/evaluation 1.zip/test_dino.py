import torch
import torchvision.transforms as transforms
from PIL import Image
import timm  # 用于加载预训练模型

import torch.nn.functional as F

# 选择DINO预训练的ViT模型
model = torch.hub.load('facebookresearch/dino:main', 'dino_vits16').to('cuda')

# 设备设置
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# 定义预处理步骤
transform = transforms.Compose([
    transforms.Resize(224),  
    transforms.CenterCrop(224),  
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

# 加载图片并转换
def preprocess_image(image_path):
    image = Image.open(image_path).convert("RGB")
    image = transform(image).unsqueeze(0)  # 添加batch维度
    return image.to(device)

# 获取DINO特征向量（取最后一层Transformer输出的CLS token）
def get_dino_features(model, image_tensor):
    with torch.no_grad():
        features = model(image_tensor)  # 获取特征
        # cls_token = features[:, 0, :]  # 获取CLS Token特征
    return features


def cosine_similarity(tensor1, tensor2):
    return F.cosine_similarity(tensor1, tensor2).item()

# 计算两张图片的相似度
image1 = preprocess_image("test_image/000000129445.jpg")
image2 = preprocess_image("test_image/000000201436.jpg")

features1 = get_dino_features(model, image1)
features2 = get_dino_features(model, image2)

similarity = cosine_similarity(features1, features2)
print(f"余弦相似度: {similarity:.4f}")
import pdb; pdb.set_trace()
