from transformers import CLIPProcessor, CLIPModel
from PIL import Image
import requests
import torch
import torch.nn.functional as F

# 下载图像
url = "http://images.cocodataset.org/val2017/000000039769.jpg"
image = Image.open(requests.get(url, stream=True).raw)

model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
import pdb;pdb.set_trace()

# 定义文本和多张图片
text = "A dog running on the beach"  # 你的文本描述
image_paths = ["image1.jpg", "image2.jpg", "image3.jpg"]  # 多张图片
images = [Image.open(img_path) for img_path in image_paths]
# 预处理文本和图片
inputs = processor(text=[text], images=images, return_tensors="pt", padding=True)

# 获取文本和图片的 embedding
with torch.no_grad():
    text_features = model.get_text_features(**{k: v for k, v in inputs.items() if k.startswith("input_ids")})  # Shape: [1, 512]
    image_features = model.get_image_features(**{k: v for k, v in inputs.items() if k.startswith("pixel_values")})  # Shape: [N, 512]

# 计算文本与每张图片的相似度
similarities = F.cosine_similarity(text_features, image_features)  # Shape: [N]
