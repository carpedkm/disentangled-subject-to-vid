import json

x = {
    '000000129445.mp4': '000000129445.jpg',
    '000000201436.mp4': '000000201436.jpg',
}

with open('test.json', 'w') as f:
    json.dump(x, f, indent=4)

y = {
    '000000129445.mp4': 'A cat is sitting in a cozy kitchen, playfully pawing at a small object on the floor. The background shows wooden cabinets and a stainless steel refrigerator, with warm lighting creating a homely atmosphere. The cat occasionally looks around, its tail flicking back and forth.',
    '000000201436.mp4': 'A bottle sits on a wooden kitchen counter, illuminated by the warm glow of a nearby lamp. The camera slowly pans around, capturing the cozy ambiance of the kitchen, with a window showing a serene evening sky in the background. The bottle reflects the light, creating a soft, inviting atmosphere.'
}

with open('test_prompt.json', 'w') as f:
    json.dump(y, f, indent=4)